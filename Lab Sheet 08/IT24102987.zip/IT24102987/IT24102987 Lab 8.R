setwd("C:\\Users\\SAHAN\\Desktop\\P\\IT24102987")

#import data set
exercise<-read.table("Exercise - LaptopsWeights.txt",header = TRUE)
fix(exercise)
attach(exercise)


#Q1
#calculate mean & varience
popmean <- mean(Weight.kg.)
popstd  <- sd(Weight.kg.)

popmean
popstd


# Q2
## Get 25 random samples of size 6, with replacement
s.means <- c()
s.stds  <- c()

for(i in 1:25){
  s <- sample(Weight.kg., 6, replace=TRUE)
  s.means[i] <- mean(s)
  s.stds[i]  <- sd(s)
}

# Create a table of results
samples_table <- data.frame(
  Sample = 1:25,
  Mean   = s.means,
  StdDev = s.stds
)

samples_table

# Q3
## Mean and standard deviation of the Sample
samplemean  <- mean(s.means)
samplestd   <- sd(s.means)

samplemean
samplestd

#compare with population mean and true standard deviation.
popmean
popstd/sqrt(6)
