setwd("C:\\Users\\SAHAN\\Desktop\\New folder (4)\\IT24102987")
getwd()

#Q1 
# i).Generate a random sample of size 25 for the baking time
baking_times <- rnorm(25, mean=45, sd=2)
baking_times

#ii). 
##Hypothesis: H0: μ >= 46 vs H1: μ < 46
t.test(baking_times, mu=46, alternative="less")
